document.getElementById("form").addEventListener("submit", function (e) {
  e.preventDefault();
  let dataform = document.getElementById("form-name").value;

  let api = `https://raw.githubusercontent.com/Hipo/university-domains-list/master/world_universities_and_domains.json`;
  fetch(api)
    .then((response) => response.json())
    .then((data) => {
      let filterData = data.filter((item) => item.country === dataform);

      function buildTable(filterData) {
        const table = document.createElement("table");
        const header = document.createElement("thead");
        const body = document.createElement("tbody");

        console.log(filterData.length);

        for (let i = 1; i <= filterData.length; i++) {
          console.log(i);
        }

        filterData.forEach((datas, i) => {
          if (i === 0) {
            const headerRow = document.createElement("tr");
            Object.keys(datas).map((k) => {
              const headerCell = document.createElement("td");
              headerCell.innerHTML = k;
              headerRow.appendChild(headerCell);
              header.appendChild(headerRow);
            });
            table.appendChild(header);
          }
          const tr = document.createElement("tr");

          Object.values(datas).map((k) => {
            tr.innerHTML = ` 
            <td>${i + 1}</td>
                    <td><a href="${datas.web_pages}">${datas.web_pages}</a></td>
                    <td>${datas.name}</td>
                    <td>${datas.alpha_two_code}</td>
                    <td>${k}</td>
                    <td>${datas.domains}</td>
                    <td>${datas.country}</td>
                   `;
          });

          table.appendChild(tr);
        });
        return table;
      }

      document.body.appendChild(buildTable(filterData));
    });
});
document.querySelector("#reset").onclick = function () {
  document.querySelector("table").remove();
};
